
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split 
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import random
from sklearn.metrics import accuracy_score
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.ensemble import RandomForestClassifier

#TODO explain the gradient clipping 

def mean_negative_loglikelihood(Y, pYhat):
    epsilon = 1e-15  # Small constant to avoid division by zero
    pYhat = np.clip(pYhat, epsilon, 1 - epsilon)  # Clip values to avoid extreme values
    log1 = np.log(pYhat)
    log2 = np.log(1 - pYhat)
    return -(np.mean((Y * log1) + ((1 - Y) * log2)))



def accuracy(Y, Yhat):
    """
    Function for computing accuracy.

    Y is a vector of the true labels and Yhat is a vector of estimated 0/1 labels
    """

    return np.sum(Y==Yhat)/len(Y)

def sigmoid(V):
    """
    Stable implementation of the sigmoid function
    """
    V_clip = np.clip(V, -700, 700)  # Clip values to avoid overflow/underflow
    return 1 / (1 + np.exp(-V_clip))


class LogisticRegression:

    def __init__(self, learning_rate=0.1, lamda=None):
        """
        Constructor for the class. Learning rate is
        any positive number controlling step size of gradient descent.
        Lamda is a positive number controlling the strength of regularization.
        When None, no penalty is added.
        """

        self.learning_rate = learning_rate
        self.lamda = lamda
        self.theta = None # theta is initialized once we fit the model

    def _calculate_gradient(self, Xmat, Y, theta_p, h=1e-5):
        """
        Helper function for computing the gradient at a point theta_p.
        """

        # initialize an empty gradient vector
        n, d = Xmat.shape
        grad_vec = np.zeros(d)

        # Calculate the predictions:
        pred = mean_negative_loglikelihood(Y, sigmoid(Xmat @ theta_p))

        #add the L2 regularization penalty
        if self.lamda != None and self.lamda != 0:
            pred += self.lamda * np.sum((theta_p)**2)

        
        for i in range(d):
            # Update the value of theta without changing the original theta_p value
            theta_p_changed = theta_p.copy()
            theta_p_changed[i] += h

            # Calculate new predictions and negative log likelihood
            new_pred = sigmoid(Xmat @ theta_p_changed)
            loss_new_error = mean_negative_loglikelihood(Y, new_pred)

            #L2 regularization loss
            if self.lamda != None and self.lamda != 0:
                loss_new_error += self.lamda * np.sum((theta_p_changed)**2) 
            # Calculate the partial derivative of the loss function
            partial_der = (loss_new_error - pred) / h
            grad_vec[i] = partial_der

        return grad_vec

    def fit(self, Xmat, Y, max_iterations=1000, tolerance=1e-6, verbose=False):
        """
        Fit a logistic regression model using training data Xmat and Y.
        """

        # add a column of ones for the intercept
        n, d = Xmat.shape

        # initialize theta and theta new randomly
        theta = np.random.uniform(-1, 1, d)
        theta_new = np.random.uniform(-1, 1, d)
        iteration = 0

        # keep going until convergence

        while iteration < max_iterations:
            gradient = self._calculate_gradient(Xmat, Y, theta)
            
            #get value of new theta 
            theta_new = theta - self.learning_rate * gradient
            
            #check if the mean absolute difference is less than the tolerance argument
            if np.mean(np.abs(theta_new - theta)) < tolerance:
                break

            #updating the value of theta to be our new guess 
            theta = theta_new
            iteration += 1
            

        # set the theta attribute of the model to the final value from gradient descent
        self.theta = theta_new.copy()

    def predict(self, Xmat):
        """
        Predict 0/1 labels for a data matrix Xmat based on the following rule:
        if p(Y=1|X) > 0.5 output a label of 1, else output a label of 0
        """
        n, _ = Xmat.shape
        Yhat = np.zeros(n, dtype=int)  # Initialize an array for integer predictions

        for i in range(n):
            # Use direct indexing to access the ith row of Xmat and make the prediction
           # print(Xmat[i, :])
            if sigmoid(Xmat.iloc[i, :] @ self.theta) > 0.5:
                Yhat[i] = 1
            else:
                Yhat[i] = 0

        return Yhat



def songweather_data():

    data = pd.read_csv("top10bestandworst2.csv")
    # pre-process the data here and drop irrelevant features
    data = data.drop(columns=["Spotify ID", "Artist IDs", "Genres", "Artist Name(s)"])
    
    # Filter data based on years
    #2000-2016 for training
    train_data = data[(data['year'] >= 2000) & (data['year'] < 2017)]

    #2017-2018 for validation
    val_data = data[(data['year'] >= 2017) & (data['year'] <= 2018)]

    #2019-2020 for testing
    test_data = data[(data['year'] > 2018) & (data['year'] <= 2020)]

    # Split the data into features (X) and target variable (Y)
    X_train = train_data[['tmax', 'tmin', 'af', 'rain', 'sun', 'Danceability', 'Energy', 'Key', 'Loudness', 'Speechiness', 'Acousticness', 'Instrumentalness', 'Liveness', 'Valence', 'Tempo', 'season_Fall', 'season_Spring', 'season_Summer', 'season_Winter']]
    Y_train = train_data['popularity']

    X_val = val_data[['tmax', 'tmin', 'af', 'rain', 'sun', 'Danceability', 'Energy', 'Key', 'Loudness', 'Speechiness', 'Acousticness', 'Instrumentalness', 'Liveness', 'Valence', 'Tempo', 'season_Fall', 'season_Spring', 'season_Summer', 'season_Winter']]
    Y_val = val_data['popularity']

    X_test = test_data[['tmax', 'tmin', 'af', 'rain', 'sun', 'Danceability', 'Energy', 'Key', 'Loudness', 'Speechiness', 'Acousticness', 'Instrumentalness', 'Liveness', 'Valence', 'Tempo', 'season_Fall', 'season_Spring', 'season_Summer', 'season_Winter']]
    Y_test = test_data['popularity']

    # standardize the data
    mean = np.mean(X_train, axis=0)
    std = np.std(X_train, axis=0)
    X_train = (X_train - mean)/std
    X_val = (X_val - mean)/std
    X_test = (X_test - mean)/std

    return X_train, Y_train, X_val, Y_val, X_test, Y_test

def random_baseline(X_val, Y_val):
    # Generate random predictions with equal probability for both classes
    Yhat_val_random = np.random.randint(0, 2, size=X_val.shape[0])
    # Calculate accuracy
    accuracy_random = np.sum(Yhat_val_random == Y_val) / len(Y_val)
    return accuracy_random, Yhat_val_random


def main():
    # Load dataset
    Xmat_train, Y_train, Xmat_val, Y_val, Xmat_test, Y_test = songweather_data()

    
    ######################################
    # Logistic Regression
    #####################################
    # Initialize the logistic regression model
    model = LogisticRegression(learning_rate=0.001)
    # Fit the logistic regression model on the training data
    model.fit(Xmat_train, Y_train, max_iterations=10000)
    # Make predictions on the validation set using the logistic regression model
    Yhat_val_logistic = model.predict(Xmat_val)
    # Print accuracy on the validation set for the logistic regression model
    print("Validation Accuracy (Logistic Regression):", accuracy(Y_val, Yhat_val_logistic))
     # Make predictions on the validation set using the model
    Yhat_test = model.predict(Xmat_test)
    # Print accuracy on the validation set for the Random Forest model
    logistic_regression_test = accuracy_score(Y_test, Yhat_test)
    print("Test Accuracy (Logistic Regression):", logistic_regression_test)


    ######################################
    # Random Forest
    #####################################
     # Initialize the Random Forest model
    random_forest_model = RandomForestClassifier(n_estimators=3000, max_depth=100, random_state=42)
    # Fit the model on the training data
    random_forest_model.fit(Xmat_train, Y_train)
    # Make predictions on the validation set using the model
    Yhat_val = random_forest_model.predict(Xmat_val)
    # Print accuracy on the validation set for the Random Forest model
    random_forest_accuracy_val = accuracy_score(Y_val, Yhat_val)
    print("Validation Accuracy (Random Forest):", random_forest_accuracy_val)
    # Make predictions on the validation set using the model
    Yhat_test = random_forest_model.predict(Xmat_test)
    # Print accuracy on the validation set for the Random Forest model
    random_forest_accuracy_test = accuracy_score(Y_test, Yhat_test)
    print("Test Accuracy (Random Forest):", random_forest_accuracy_test)
    # Get feature importances from the trained model
    feature_importances = random_forest_model.feature_importances_
    # Print feature importances
    print("Feature Importances:", feature_importances)
    features = ['tmax', 'tmin', 'af', 'rain', 'sun', 'Danceability', 'Energy', 'Key', 'Loudness', 'Speechiness', 'Acousticness', 'Instrumentalness', 'Liveness', 'Valence', 'Tempo', 'season_Fall', 'season_Spring', 'season_Summer', 'season_Winter']

    # Plot feature importances
    #plt.figure(figsize=(10, 6))
    #sns.barplot(x=feature_importances, y=features)
    #plt.title("Random Forest Feature Importances")
    #plt.xlabel("Feature Importance")
    #plt.ylabel("Features")
    #plt.show()

    ######################################
    # Random Classifier
    #####################################
    accuracy_random, Yhat_random = random_baseline(Xmat_val, Y_val)
    print("Random Baseline Validaiton Accuracy:", accuracy_random)
    accuracy_random2, Yhat_random2 = random_baseline(Xmat_test, Y_test)
    print("Random Baseline Test Accuracy:", accuracy_random2)
    

if __name__ == "__main__":
    main()








